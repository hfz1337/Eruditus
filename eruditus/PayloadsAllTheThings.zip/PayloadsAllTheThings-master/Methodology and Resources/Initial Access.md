# Initial Access

:warning: Content of this page has been moved to [InternalAllTheThings/redteam/access/initial-access](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/initial-access/)

- [Complex Chains](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/initial-access/#complex-chains)
- [Container](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/initial-access/#container)
- [Payload](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/initial-access/#payload)
    - [Binary Files](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/initial-access/#binary-files)
    - [Code Execution Files](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/initial-access/#code-execution-files)
    - [Embedded Files](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/initial-access/#embedded-files)
- [Code Signing](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/initial-access/#code-signing)
